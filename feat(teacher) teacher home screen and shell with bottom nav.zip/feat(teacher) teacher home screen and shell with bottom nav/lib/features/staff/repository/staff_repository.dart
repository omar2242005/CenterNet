import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../../../core/errors/error_mapper.dart';
import '../../../core/errors/failure.dart';
import '../../../core/firestore_paths.dart';
import '../../../core/utils/link_code_generator.dart';
import '../../linking/models/invite_code.dart';
import '../models/staff_invite_issued.dart';
import '../models/staff_member.dart';
import '../models/staff_roster.dart';

/// إدارة الموظفين (جانب الأدمن): إنشاء كود دعوة، وعرض الموظفين،
/// وتغيير الدور، وتعطيل/تفعيل العضو.
///
/// الـ Rules هي الحكم: لو المستخدم مش أدمن في السنتر الكتابة بتترفض
/// ويتحوّل الرفض لـ [Failure.permission].
class StaffRepository {
  StaffRepository(
    this._auth,
    this._db, {
    DateTime Function()? now,
    String Function()? generateCode,
  }) : _now = now ?? DateTime.now,
       _generateCode = generateCode ?? (() => LinkCodeGenerator.generate());

  final FirebaseAuth _auth;
  final FirebaseFirestore _db;
  final DateTime Function() _now;
  final String Function() _generateCode;

  /// أقصى مدة انتظار للكتابة (الإنشاء محتاج نت، زي إنشاء السنتر).
  static const Duration createTimeout = Duration(seconds: 20);

  /// عدد محاولات توليد كود جديد لو الكود طلع متكرر (احتمال شبه معدوم).
  static const int maxCodeAttempts = 5;

  /// بينشئ كود دعوة موظف (معلم أو مساعد) لسنتر الأدمن الحالي.
  ///
  /// الخطوات: يقرا `users/{uid}.centerId` (للتوجيه بس) ← يقرا اسم السنتر ←
  /// يولّد كود ويتأكد إنه مش موجود (من السيرفر) ← يكتب `inviteCodes/{code}`.
  Future<StaffInviteIssued> createStaffInvite({
    required String name,
    required StaffInviteRole role,
  }) {
    return ErrorMapper.guard(() async {
      final uid = _auth.currentUser?.uid;
      if (uid == null) throw const Failure.permission();

      if (name.trim().isEmpty) {
        throw const Failure.validation('اكتب اسم الموظف.');
      }

      final userSnap = await _db.doc(FirestorePaths.user(uid)).get();
      final centerId = userSnap.data()?['centerId'];
      if (centerId is! String) {
        throw const Failure.notFound(
          message: 'أنشئ سنتر أولًا قبل دعوة موظفين.',
        );
      }

      final centerSnap = await _db.doc(FirestorePaths.center(centerId)).get();
      final centerName = (centerSnap.data()?['name'] as String?) ?? '';

      for (var attempt = 0; attempt < maxCodeAttempts; attempt++) {
        final id = _generateCode();
        final ref = _db.doc(FirestorePaths.inviteCode(id));

        // من السيرفر مباشرة: لو أوفلاين بيفشل فورًا بدل ما يتعلق.
        final existing = await ref.get(const GetOptions(source: Source.server));
        if (existing.exists) continue;

        final invite = InviteCode.staff(
          id: id,
          centerId: centerId,
          createdBy: uid,
          role: role,
          name: name,
          now: _now(),
        );
        await ref.set(invite.toCreateMap()).timeout(createTimeout);
        return StaffInviteIssued(invite: invite, centerName: centerName);
      }
      throw const Failure.unknown();
    });
  }

  /// بيحمّل أعضاء سنتر الأدمن الحالي (من السيرفر، عشان القائمة متبقاش قديمة).
  ///
  /// `users/{uid}.centerId` للتوجيه بس. الصلاحية الحقيقية من الـ Rules:
  /// قراءة القائمة لأعضاء السنتر النشطين بس.
  Future<StaffRoster> loadStaff() {
    return ErrorMapper.guard(() async {
      final uid = _requireUid();
      final centerId = await _myCenterId(uid);

      final snap = await _db
          .collection(FirestorePaths.members(centerId))
          .get(const GetOptions(source: Source.server))
          .timeout(createTimeout);

      final members = <StaffMember>[];
      for (final doc in snap.docs) {
        try {
          members.add(StaffMember.fromMap(doc.id, doc.data()));
        } on FormatException {
          // الـ Rules بتفرض شكل مستند العضو، فالحالة دي مش متوقعة.
          // بنتخطى المستند التالف بدل ما نوقّع الشاشة كلها.
          continue;
        }
      }
      members.sort(StaffRoster.compare);
      return StaffRoster(centerId: centerId, members: members);
    });
  }

  /// بيعطّل الموظف (`active=false`) أو بيرجّع تفعيله. مفيش حذف.
  Future<void> setActive({
    required String centerId,
    required String uid,
    required bool active,
  }) {
    return ErrorMapper.guard(() async {
      _guardNotSelf(uid, 'لا يمكنك تعطيل حسابك أنت.');
      await _db
          .doc(FirestorePaths.member(centerId, uid))
          .update(<String, dynamic>{'active': active})
          .timeout(createTimeout);
    });
  }

  String _requireUid() {
    final uid = _auth.currentUser?.uid;
    if (uid == null) throw const Failure.permission();
    return uid;
  }

  void _guardNotSelf(String targetUid, String message) {
    if (_requireUid() == targetUid) throw Failure.validation(message);
  }

  Future<String> _myCenterId(String uid) async {
    final userSnap = await _db.doc(FirestorePaths.user(uid)).get();
    final centerId = userSnap.data()?['centerId'];
    if (centerId is! String) {
      throw const Failure.notFound(
        message: 'أنشئ سنتر أولًا قبل إدارة الموظفين.',
      );
    }
    return centerId;
  }
}
